package com.deeprooted.ordermanager.models.producecomponent;

public class Onion extends Produce {

    //other Onion specific property

    public Onion(String name, String id){
        super(name, id);
    }

    //other Onion specific behaviours
}
