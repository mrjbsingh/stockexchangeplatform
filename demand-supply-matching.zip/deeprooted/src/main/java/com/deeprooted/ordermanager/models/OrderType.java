package com.deeprooted.ordermanager.models;

public enum OrderType {
    BUY_ORDER,
    SELL_ORDER
}
