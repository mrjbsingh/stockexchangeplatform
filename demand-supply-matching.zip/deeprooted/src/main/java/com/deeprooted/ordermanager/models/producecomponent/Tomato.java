package com.deeprooted.ordermanager.models.producecomponent;

import com.deeprooted.ordermanager.models.producecomponent.Produce;

public class Tomato extends Produce {

    //other Tomato specific property

    public Tomato(String name, String id){
        super(name, id);
    }

    //other Tomato specific behaviours
}
