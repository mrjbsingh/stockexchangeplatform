package com.deeprooted.ordermanager.models;

public class BaseEntity {
    Long id;
}
