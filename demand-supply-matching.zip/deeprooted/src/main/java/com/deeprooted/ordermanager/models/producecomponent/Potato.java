package com.deeprooted.ordermanager.models.producecomponent;

public class Potato extends Produce {
    //Potato Specific property

    public Potato(String produceName, String produceId) {
        super(produceName, produceId);
    }

    //Potato Specific behaviours
}
