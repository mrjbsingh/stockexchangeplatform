package com.deeprooted.ordermanager.models.producecomponent;

public class LadyFinger extends Produce {

    //other LadyFinger specific property

    public LadyFinger(String name, String id){
        super(name, id);
    }

    //other LadyFinger specific behaviours
}
