package com.deeprooted.ordermanager.exceptions;

public class ProduceNotFoundException extends RuntimeException{

    public ProduceNotFoundException(String msg){
        super(msg);
    }
}
